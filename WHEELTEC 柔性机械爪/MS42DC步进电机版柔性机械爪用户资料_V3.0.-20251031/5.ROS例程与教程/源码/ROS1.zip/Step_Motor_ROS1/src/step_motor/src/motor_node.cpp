#include "ros/ros.h"
#include "step_motor/Motor.h"
#include "serial/serial.h"

class Step_Motor
{
private:
  uint8_t dir;
  uint8_t sub_divide;
  uint8_t mode;
  ros::NodeHandle n;
  std::string usart_port_name;
  uint32_t baudrate;
  ros::Publisher pub;
  ros::Subscriber sub;
  uint16_t speed;
  uint32_t angle;
  uint32_t rcc_check;
public:
  serial::Serial Stm32_Serial;
  uint8_t send_data[11];
  uint8_t recv_data[9];
  uint8_t check_rcc(uint8_t *data,uint8_t num);
  void motor_control_callback(const step_motor::Motor &msg);
  Step_Motor();
};

Step_Motor::Step_Motor()
{

  ros::NodeHandle private_nh("~"); //Create a node handle //创建节点句柄
  //The private_nh.param() entry parameter corresponds to the initial value of the name of the parameter variable on the parameter server
  //private_nh.param()入口参数分别对应：参数服务器上的名称  参数变量名  初始值
  usart_port_name="/dev/motor_serial";
  baudrate=115200;
  pub=n.advertise<step_motor::Motor>("motor_state",10);
  sub=n.subscribe("motor_control",10,&Step_Motor::motor_control_callback,this);
  try
  { 
    //Attempts to initialize and open the serial port //尝试初始化与开启串口
    Stm32_Serial.setPort(usart_port_name); //Select the serial port number to enable //选择要开启的串口号
    Stm32_Serial.setBaudrate(baudrate); //Set the baud rate //设置波特率
    serial::Timeout _time = serial::Timeout::simpleTimeout(2000); //Timeout //超时等待
    Stm32_Serial.setTimeout(_time);
    Stm32_Serial.open(); //Open the serial port //开启串口
  }
  catch (serial::IOException& e)
  {
    ROS_ERROR_STREAM("wheeltec_robot can not open serial port,Please check the serial port cable! "); //If opening the serial port fails, an error message is printed //如果开启串口失败，打印错误信息
  }
  if(Stm32_Serial.isOpen())
  {
    ROS_INFO_STREAM("wheeltec_robot serial port opened"); //Serial port opened successfully //串口开启成功提示
  }
}

void Step_Motor::motor_control_callback(const step_motor::Motor &msg)
{
  if(!msg.state)
  {
    send_data[0]=0x7b;
    send_data[1]=msg.id;
    send_data[2]=msg.mode;
    mode=msg.mode;
    send_data[3]=msg.dir;
    dir=msg.dir;
    send_data[4]=msg.sub_divide;
    sub_divide=msg.sub_divide;
    send_data[5]=msg.angle>>8;
    send_data[6]=msg.angle;
    send_data[7]=msg.speed>>8;
    send_data[8]=msg.speed;
    send_data[9]=check_rcc(send_data,9);
    send_data[10]=0x7d;
  }
  else
  {
    send_data[0]=0x7b;
    send_data[1]=msg.id;
    send_data[2]=0;
    send_data[3]=0;
    send_data[4]=0;
    send_data[5]=0;
    send_data[6]=0;
    send_data[7]=0;
    send_data[8]=0;
    send_data[9]=check_rcc(send_data,9);
    send_data[10]=0x7d;
  }
  try
  {
    Stm32_Serial.write(send_data,sizeof (send_data)); //Sends data to the downloader via serial port //通过串口向下位机发送数据 
    if(msg.state)
    {
      ros::Duration(0.01).sleep();
      Stm32_Serial.read(recv_data,9);
      if(check_rcc(recv_data,8)==recv_data[8])
      {
        step_motor::Motor motor;
        speed=recv_data[2]<<8|recv_data[3];
        angle=recv_data[4]<<24|recv_data[5]<<16|recv_data[6]<<8|recv_data[7];
        motor.id=msg.id;
        motor.angle=angle;
        motor.state=recv_data[1];
        motor.speed=speed;
        motor.dir=dir;
        motor.mode=mode;
        motor.sub_divide=sub_divide;
        pub.publish(motor);
      }
    }
    // for(uint8_t i=0;i<sizeof(send_data);i++)
    // {
    //   printf("%x ",send_data[i]);
    // }


    // for(uint8_t i=0;i<sizeof(recv_data);i++)
    // {
    //   printf("%x ",recv_data[i]);
    // }
    //  printf("\n");
  }
  catch (serial::IOException& e)   
  {
    ROS_ERROR_STREAM("Unable to send data through serial port"); //If sending data fails, an error message is printed //如果发送数据失败，打印错误信息
  }
}

uint8_t Step_Motor::check_rcc(uint8_t *data,uint8_t num)
{
  uint8_t check=0;
  for(uint8_t i=0;i<num;i++)
  {
    check^=data[i];
  }
  return check; 
}


int main(int argc, char** argv)
{
  ros::init(argc, argv, "step_motor"); //ROS initializes and sets the node name //ROS初始化 并设置节点名称 
  Step_Motor step_motor; //Instantiate an object //实例化一个对象
  ros::spin();
  return 0;  
} 