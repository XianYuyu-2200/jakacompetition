#!/usr/bin/env python3
# coding=utf-8
import rospy
from step_motor.msg import Motor
import sys, select, termios, tty

msg = """
Control Your motor!
---------------------------
   q    w        r
   a    s    d   f
   z    x        v

q/a : increase/decrease resolution_ratio
r/v : increase/decrease id 
w/s/x : w/x increase/decrease speed  s stop 
z: change direction
f: send motor state request
z: sub-divide
CTRL-C to quit
"""
e = """
Communications Failed
"""

#获取键值函数
def getKey():
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    if rlist:
        key = sys.stdin.read(1)
    else:
        key = ''
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key


#主函数
if __name__=="__main__":
    settings = termios.tcgetattr(sys.stdin) #获取键值初始化，读取终端相关属性
    rospy.init_node('arm_teleop') #创建ROS节点
    motor=Motor()
    motor.speed=0

    pub = rospy.Publisher('motor_control', Motor, queue_size=6) 
    resolution_ratio=1
    temp_speed=0
    pow=1
    motor.id=1
    motor.sub_divide=32
    try:
        print(msg) #打印控制说明
        while (1):
            key = getKey() #获取键值
            if key=='w':
                motor.mode=1
                motor.speed+=resolution_ratio
                print("current speed:",motor.speed,end="\n")
                pub.publish(motor)
            if key=='s':
                temp_speed=motor.speed
                motor.mode=1
                motor.speed=0
                print("stop\n")
                pub.publish(motor)
                motor.speed=temp_speed
            if key=='x':
                motor.mode=1
                if motor.speed>=resolution_ratio:
                    motor.speed-=resolution_ratio
                print("current speed:",motor.speed,end="\n")
                pub.publish(motor)
            
            if key=='d':               
                motor.dir=not motor.dir
                if motor.dir==0:
                    print ("foreward rotation\n")
                else:
                    print ("reverse rotation\n")
                pub.publish(motor)

            if key=='f':
                motor.state=1
                pub.publish(motor)
                print ("send motor state request\n")
                motor.state=0

            if key=='q':
                resolution_ratio+=1
                print("current resolution_ratio:",resolution_ratio,end="\n")
                pub.publish(motor)
            if key=='a':
                if resolution_ratio>1:
                    resolution_ratio-=1
                print("current resolution_ratio:",resolution_ratio,end="\n")
                pub.publish(motor)
            if key=='z':
                motor.sub_divide=2**pow
                pub.publish(motor)
                if pow<5:
                    pow+=1
                else:
                    pow=0
                print("current sub-divide:",motor.sub_divide)

            if key=='r':
                motor.id+=1
                print("current motor id:",motor.id,end="\n")
                pub.publish(motor)
            if key=='v':
                if motor.id>1:
                    motor.id-=1
                print("current motor id:",motor.id,end="\n")
                pub.publish(motor)
                

            #长期识别到不明键值，相关变量置0
            if (key == '\x03'):
                    break

            # #其他按键不做处理
            else:
                pass

           

    #运行出现问题则程序终止并打印相关错误信息
    except Exception as e:
        print(e)

    #程序结束前打印消息提示
    finally:
        print("Keyboard control off")

    #程序结束前设置终端相关属性
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)

